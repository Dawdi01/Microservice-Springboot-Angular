package com.example.gestionmateriel.dto;

import lombok.Data;

@Data
public class UserResponseDTO {
    private String nom;
    private String prenom;
    private String email;
}
