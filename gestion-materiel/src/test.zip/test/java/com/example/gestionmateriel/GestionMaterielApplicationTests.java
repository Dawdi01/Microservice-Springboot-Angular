package com.example.gestionmateriel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionMaterielApplicationTests {

    @Test
    void contextLoads() {
    }

}
